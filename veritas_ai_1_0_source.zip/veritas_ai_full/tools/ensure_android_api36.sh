#!/usr/bin/env bash
set -euo pipefail
if [ -f android/app/build.gradle.kts ]; then
  python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle.kts')
s=p.read_text()
s=s.replace('targetSdk = flutter.targetSdkVersion', 'targetSdk = 36')
p.write_text(s)
PY
elif [ -f android/app/build.gradle ]; then
  python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
s=s.replace('targetSdk = flutter.targetSdkVersion', 'targetSdkVersion 36')
p.write_text(s)
PY
fi
