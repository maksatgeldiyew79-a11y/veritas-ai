#!/usr/bin/env bash
set -euo pipefail
flutter --version
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter test
