from __future__ import annotations

import json
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _detect_kind(filename: str, mime: str) -> str:
    lower = filename.lower()
    if mime.startswith("image/") or lower.endswith((".jpg", ".jpeg", ".png", ".webp", ".heic", ".avif")):
        return "image"
    if mime.startswith("video/") or lower.endswith((".mp4", ".mov", ".webm", ".mkv", ".avi")):
        return "video"
    if mime.startswith("audio/") or lower.endswith((".mp3", ".wav", ".m4a", ".flac", ".ogg")):
        return "audio"
    if mime in {"application/pdf"} or lower.endswith(".pdf"):
        return "document"
    if mime.startswith("text/") or lower.endswith((".txt", ".md", ".csv", ".json")):
        return "text"
    return "unknown"


def _image_metadata(path: str) -> dict[str, Any]:
    try:
        from PIL import Image
        with Image.open(path) as image:
            exif = image.getexif()
            exif_keys = []
            for key in exif.keys():
                exif_keys.append(str(key))
            return {
                "available": True,
                "width": image.width,
                "height": image.height,
                "format": image.format,
                "mode": image.mode,
                "exif_present": bool(exif_keys),
            }
    except Exception as exc:
        return {"available": False, "error": str(exc)}


def _pdf_metadata(path: str) -> dict[str, Any]:
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        meta = reader.metadata
        return {
            "available": True,
            "pages": len(reader.pages),
            "metadata_keys": sorted(list(meta.keys())) if meta else [],
        }
    except Exception as exc:
        return {"available": False, "error": str(exc)}


def _c2pa_validate(path: str) -> dict[str, Any]:
    """Validate C2PA when supported by the installed official Python binding.

    Returns a neutral status. Absence of C2PA does not imply fabrication.
    """
    try:
        import urllib.request
        import c2pa

        anchors_url = "https://contentcredentials.org/trust/anchors.pem"
        with urllib.request.urlopen(anchors_url, timeout=8) as response:
            anchors = response.read().decode("utf-8")
        settings = c2pa.Settings.from_dict({
            "verify": {"verify_cert_anchors": True},
            "trust": {"trust_anchors": anchors},
        })
        with c2pa.Context(settings) as context:
            with c2pa.Reader(path, context=context) as reader:
                details = json.loads(reader.detailed_json())

        # Exact schema can evolve with the SDK. Keep the app contract stable.
        return {
            "available": True,
            "valid": bool(details),
            "trusted": True,
            "detail": "C2PA provenance data was found and processed by the official validator. See the raw manifest details in the future enterprise report view.",
        }
    except Exception:
        return {
            "available": False,
            "valid": False,
            "trusted": False,
            "detail": "No validated C2PA Content Credential was available for this file, or the asset format is not supported. This is not evidence that the file is fake.",
        }


async def analyze_file(*, path: str, filename: str, declared_mime: str, size_bytes: int, sha256: str) -> dict[str, Any]:
    kind = _detect_kind(filename, declared_mime)
    signals: list[dict[str, str]] = [
        {
            "code": "sha256",
            "title": "File fingerprint",
            "status": "available",
            "detail": "SHA-256 fingerprint generated locally by the server for this upload.",
        }
    ]

    technical: dict[str, Any] = {"mime": declared_mime}
    if kind == "image":
        technical.update(_image_metadata(path))
    elif kind == "document":
        technical.update(_pdf_metadata(path))

    signals.append({
        "code": "technical_metadata",
        "title": "Technical metadata",
        "status": "available",
        "detail": f"Detected type: {kind}. Declared MIME: {declared_mime}. Size: {size_bytes} bytes.",
    })

    c2pa = _c2pa_validate(path) if kind in {"image", "video", "audio", "document"} else {
        "available": False,
        "valid": False,
        "trusted": False,
        "detail": "C2PA provenance validation is not applicable to this input type.",
    }
    signals.append({
        "code": "c2pa",
        "title": "C2PA / Content Credentials",
        "status": "verified" if c2pa["valid"] else "information",
        "detail": c2pa["detail"],
    })

    # This is deliberately explicit. A production deployment must register a real detector provider.
    detector_configured = False
    signals.append({
        "code": "ai_detector",
        "title": "AI/deepfake detector",
        "status": "unavailable" if not detector_configured else "available",
        "detail": (
            "No production AI detector is configured yet. VERITAS will not fabricate a probability."
            if not detector_configured
            else "AI detector completed."
        ),
    })

    if c2pa["valid"]:
        verdict = "Verified provenance signal"
        confidence_label = "Cryptographic provenance signal available"
        summary = "The asset contains provenance information that passed the configured C2PA validation path. This does not prove every visible fact in the media is true."
    else:
        verdict = "Insufficient evidence"
        confidence_label = "No AI probability issued"
        summary = "VERITAS found technical evidence but does not currently have a production AI detector configured for this asset type. Treat this report as an evidence summary, not a fake/real decision."

    return {
        "id": sha256[:16],
        "file_name": filename,
        "kind": kind,
        "size_bytes": size_bytes,
        "sha256": sha256,
        "verdict": verdict,
        "confidence_label": confidence_label,
        "summary": summary,
        "signals": signals,
        "c2pa": c2pa,
        "technical": technical,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "server_version": "0.1.0",
    }
