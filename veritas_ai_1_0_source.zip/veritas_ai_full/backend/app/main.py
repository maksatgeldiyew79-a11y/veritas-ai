from __future__ import annotations

import hashlib
import mimetypes
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .analyzer import analyze_file

app = FastAPI(title="VERITAS AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)

MAX_BYTES = 50 * 1024 * 1024


def safe_suffix(filename: str | None) -> str:
    suffix = Path(filename or "").suffix.lower()
    return suffix[:10]


@app.get("/health")
async def health():
    return {"status": "ok", "service": "veritas-ai", "version": "0.1.0"}


@app.post("/v1/analyze")
async def analyze(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Filename is required")

    total = 0
    hasher = hashlib.sha256()
    with tempfile.NamedTemporaryFile(delete=False, suffix=safe_suffix(file.filename)) as tmp:
        path = tmp.name
        try:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_BYTES:
                    raise HTTPException(status_code=413, detail="File exceeds 50 MB MVP limit")
                hasher.update(chunk)
                tmp.write(chunk)
        finally:
            await file.close()

    try:
        detected_type = file.content_type or mimetypes.guess_type(file.filename)[0] or "application/octet-stream"
        result = await analyze_file(
            path=path,
            filename=file.filename,
            declared_mime=detected_type,
            size_bytes=total,
            sha256=hasher.hexdigest(),
        )
        return result
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
