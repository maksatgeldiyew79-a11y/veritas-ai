from veritas_ai.app.analyzer import _detect_kind


def test_detect_kind_image():
    assert _detect_kind('x.jpg', 'image/jpeg') == 'image'


def test_detect_kind_video():
    assert _detect_kind('x.mp4', 'video/mp4') == 'video'


def test_detect_kind_pdf():
    assert _detect_kind('x.pdf', 'application/pdf') == 'document'
