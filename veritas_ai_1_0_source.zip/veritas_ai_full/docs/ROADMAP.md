# VERITAS AI roadmap

## Phase 1 — working evidence engine
- File fingerprinting
- Technical metadata
- C2PA validation
- Honest report semantics
- Local history
- PDF export

## Phase 2 — actual AI detection
Implement provider adapters behind one interface:

```text
DetectorProvider
  ├── ImageDetectorProvider
  ├── VideoDetectorProvider
  └── AudioDetectorProvider
```

Each provider must return:

- model name/version
- calibration information
- probability / confidence
- supported media constraints
- latency
- failure state

No detector result may be presented as a guarantee.

## Phase 3 — accounts + cloud history
- Firebase Auth / equivalent
- Firestore / equivalent
- signed upload URLs
- automatic deletion policy
- App Check / abuse protection

## Phase 4 — monetization
- free daily quota
- premium quota
- Google Play Billing
- enterprise API keys

## Phase 5 — enterprise
- SSO
- audit logs
- retention policies
- batch jobs
- webhook callbacks
- SLA monitoring
