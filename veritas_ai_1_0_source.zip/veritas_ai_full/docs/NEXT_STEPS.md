# What to do next

1. Install Flutter stable and Android Studio on a PC.
2. Unzip the project.
3. Run `flutter create --platforms=android .`.
4. Run `./tools/ensure_android_api36.sh`.
5. Run `flutter pub get`.
6. Start the backend and use the `VERITAS_API_URL` dart define.
7. Build with `flutter build apk --release`.
8. For a cloud build, push the project to GitHub; the included Actions workflow will generate the APK artifact and force target API 36.

The AI detector is the next substantive engineering step. Connect a real detector behind a server-side provider interface rather than embedding a secret API key in the Android app.
