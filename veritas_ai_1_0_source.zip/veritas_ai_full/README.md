# VERITAS AI 1.0

Digital-content authenticity analysis MVP for Android.

## What is implemented

- Modern Flutter Android UI.
- File picker for images, video, audio, documents, and text.
- SHA-256 fingerprinting performed locally.
- Upload to a FastAPI analysis backend.
- Backend detects MIME/type, file size, SHA-256, image technical metadata, PDF metadata when available.
- C2PA Content Credentials validation through the official `c2pa-python` bindings when installed.
- Pluggable AI detector interface. The app never fabricates a deepfake probability when no real detector model/service is connected.
- Local history.
- PDF report generation and sharing.
- Architecture ready for authenticated accounts, billing, remote history, and enterprise API.

## Important product rule

A missing C2PA credential is **not** proof that content is fake. C2PA is provenance/authenticity information that can be cryptographically validated when present. The report therefore uses neutral language such as “verified provenance signal found”, “no credential found”, or “AI detector unavailable”.

## Run locally

### 1. Android project bootstrap

This repository intentionally keeps the generated Flutter platform files out of source control in this MVP bundle. With Flutter installed, from this directory run:

```bash
flutter create --platforms=android .
flutter pub get
```

Then set the API endpoint in the run command:

```bash
flutter run --dart-define=VERITAS_API_URL=http://10.0.2.2:8000
```

For a real device, replace the IP with the LAN address of the computer running FastAPI, e.g. `http://192.168.1.20:8000`.

### 2. Backend

Requirements: Python 3.10+.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

The backend includes C2PA validation using `c2pa-python==0.37.10` when the package is available. That release can read and validate C2PA manifests from supported media formats. The current code loads the official C2PA trust-anchor list at runtime before validation.

## Android / Google Play

New Android apps submitted to Google Play from 31 August 2026 must target Android 16 / API 36 or higher. After `flutter create`, confirm the generated Android project is configured accordingly before release.

## Production hardening still required

- Authentication and account recovery.
- HTTPS only.
- Object storage instead of keeping uploaded files on local disk.
- Malware scanning / file-type validation.
- Per-user quotas and abuse prevention.
- Billing via Google Play Billing.
- Real image/video/audio AI detector models or licensed detector APIs.
- Privacy policy, data retention controls, deletion endpoint, and Play Data Safety declarations.
- Logging, metrics, rate limiting, secrets management, and key rotation.
- Independent security review before enterprise use.
