class AnalysisResult {
  const AnalysisResult({
    required this.id,
    required this.fileName,
    required this.kind,
    required this.sizeBytes,
    required this.sha256,
    required this.verdict,
    required this.confidenceLabel,
    required this.summary,
    required this.signals,
    required this.c2pa,
    required this.createdAt,
    this.serverVersion = '0.1.0',
  });

  final String id;
  final String fileName;
  final String kind;
  final int sizeBytes;
  final String sha256;
  final String verdict;
  final String confidenceLabel;
  final String summary;
  final List<AnalysisSignal> signals;
  final C2paStatus c2pa;
  final DateTime createdAt;
  final String serverVersion;

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    return AnalysisResult(
      id: json['id'] as String,
      fileName: json['file_name'] as String,
      kind: json['kind'] as String,
      sizeBytes: (json['size_bytes'] as num).toInt(),
      sha256: json['sha256'] as String,
      verdict: json['verdict'] as String,
      confidenceLabel: json['confidence_label'] as String,
      summary: json['summary'] as String,
      signals: (json['signals'] as List<dynamic>)
          .map((e) => AnalysisSignal.fromJson(e as Map<String, dynamic>))
          .toList(),
      c2pa: C2paStatus.fromJson(json['c2pa'] as Map<String, dynamic>),
      createdAt: DateTime.parse(json['created_at'] as String),
      serverVersion: (json['server_version'] as String?) ?? '0.1.0',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'file_name': fileName,
        'kind': kind,
        'size_bytes': sizeBytes,
        'sha256': sha256,
        'verdict': verdict,
        'confidence_label': confidenceLabel,
        'summary': summary,
        'signals': signals.map((e) => e.toJson()).toList(),
        'c2pa': c2pa.toJson(),
        'created_at': createdAt.toIso8601String(),
        'server_version': serverVersion,
      };
}

class AnalysisSignal {
  const AnalysisSignal({
    required this.code,
    required this.title,
    required this.status,
    required this.detail,
  });

  final String code;
  final String title;
  final String status;
  final String detail;

  factory AnalysisSignal.fromJson(Map<String, dynamic> json) => AnalysisSignal(
        code: json['code'] as String,
        title: json['title'] as String,
        status: json['status'] as String,
        detail: json['detail'] as String,
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'title': title,
        'status': status,
        'detail': detail,
      };
}

class C2paStatus {
  const C2paStatus({
    required this.available,
    required this.valid,
    required this.trusted,
    required this.detail,
  });

  final bool available;
  final bool valid;
  final bool trusted;
  final String detail;

  factory C2paStatus.fromJson(Map<String, dynamic> json) => C2paStatus(
        available: json['available'] as bool,
        valid: json['valid'] as bool,
        trusted: json['trusted'] as bool,
        detail: json['detail'] as String,
      );

  Map<String, dynamic> toJson() => {
        'available': available,
        'valid': valid,
        'trusted': trusted,
        'detail': detail,
      };
}
