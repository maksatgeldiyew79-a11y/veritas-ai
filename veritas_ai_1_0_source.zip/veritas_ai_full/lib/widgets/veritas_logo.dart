import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class VeritasLogo extends StatelessWidget {
  const VeritasLogo({super.key, this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 34 : 42,
          height: compact ? 34 : 42,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(colors: [AppTheme.accent, AppTheme.accent2]),
          ),
          child: const Icon(Icons.verified_user_rounded, color: Colors.black, size: 23),
        ),
        if (!compact) ...[
          const SizedBox(width: 12),
          Text('VERITAS', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
        ]
      ],
    );
  }
}
