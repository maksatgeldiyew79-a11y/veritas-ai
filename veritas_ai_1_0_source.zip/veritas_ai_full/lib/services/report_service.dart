import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/analysis_result.dart';

class ReportService {
  Future<Uint8List> buildPdf(AnalysisResult result) async {
    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Text('VERITAS AI', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text('Digital Content Analysis Report'),
          pw.SizedBox(height: 20),
          _row('File', result.fileName),
          _row('Type', result.kind),
          _row('SHA-256', result.sha256),
          _row('Verdict', result.verdict),
          _row('Confidence', result.confidenceLabel),
          _row('Created', result.createdAt.toUtc().toIso8601String()),
          pw.SizedBox(height: 20),
          pw.Text('Summary', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Text(result.summary),
          pw.SizedBox(height: 20),
          pw.Text('Signals', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          ...result.signals.map(
            (signal) => pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 8),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('${signal.title} — ${signal.status}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.Text(signal.detail),
                ],
              ),
            ),
          ),
          pw.SizedBox(height: 10),
          pw.Text('C2PA / Content Credentials', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.Text(result.c2pa.detail),
          pw.SizedBox(height: 20),
          pw.Text(
            'Important: VERITAS AI is an analysis aid. No result should be treated as absolute proof of authenticity or fabrication without additional evidence.',
            style: const pw.TextStyle(fontSize: 9),
          ),
        ],
      ),
    );
    return doc.save();
  }

  pw.Widget _row(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 6),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(width: 90, child: pw.Text(label, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
          pw.Expanded(child: pw.Text(value)),
        ],
      ),
    );
  }
}
