import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models/analysis_result.dart';

class ApiService {
  ApiService({String? baseUrl})
      : baseUrl = baseUrl ?? const String.fromEnvironment(
          'VERITAS_API_URL',
          defaultValue: 'http://10.0.2.2:8000',
        );

  final String baseUrl;

  Future<AnalysisResult> analyze(File file) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/v1/analyze'),
    );
    request.files.add(await http.MultipartFile.fromPath('file', file.path));
    final streamed = await request.send();
    final body = await streamed.stream.bytesToString();
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      try {
        final decoded = jsonDecode(body) as Map<String, dynamic>;
        throw Exception(decoded['detail'] ?? 'Analysis request failed');
      } catch (_) {
        throw Exception('Analysis request failed (${streamed.statusCode})');
      }
    }
    return AnalysisResult.fromJson(jsonDecode(body) as Map<String, dynamic>);
  }
}
