import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/analysis_result.dart';

class HistoryService {
  static const _key = 'analysis_history_v1';

  Future<List<AnalysisResult>> read() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    return raw
        .map((s) => AnalysisResult.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  Future<void> add(AnalysisResult result) async {
    final items = await read();
    items.removeWhere((e) => e.id == result.id);
    items.insert(0, result);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _key,
      items.take(50).map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
