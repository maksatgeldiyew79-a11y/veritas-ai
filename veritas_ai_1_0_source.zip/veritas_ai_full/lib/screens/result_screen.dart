import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../models/analysis_result.dart';
import '../services/report_service.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result});
  final AnalysisResult result;

  Color _statusColor(BuildContext context) {
    if (result.verdict.toLowerCase().contains('verified')) return Colors.greenAccent;
    if (result.verdict.toLowerCase().contains('suspicious')) return Colors.orangeAccent;
    return Theme.of(context).colorScheme.primary;
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColor(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Analysis report')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [Container(width: 12, height: 12, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)), const SizedBox(width: 10), Text(result.verdict, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))]),
                  const SizedBox(height: 10),
                  Text(result.confidenceLabel, style: TextStyle(color: statusColor, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 14),
                  Text(result.summary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Signals', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                ...result.signals.map((s) => _Signal(s)),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Provenance', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(result.c2pa.detail),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('File identity', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(result.fileName),
                const SizedBox(height: 8),
                SelectableText('SHA-256: ${result.sha256}'),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () async {
              final bytes = await ReportService().buildPdf(result);
              await Printing.sharePdf(bytes: bytes, filename: 'veritas_${result.id}.pdf');
            },
            icon: const Icon(Icons.picture_as_pdf_rounded),
            label: const Text('Export PDF report'),
          ),
          const SizedBox(height: 10),
          Text('VERITAS AI is an analysis aid, not absolute proof. A missing credential does not prove fabrication.', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _Signal extends StatelessWidget {
  const _Signal(this.signal);
  final AnalysisSignal signal;
  @override
  Widget build(BuildContext context) {
    final ok = signal.status == 'verified' || signal.status == 'available';
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(ok ? Icons.check_circle_outline : Icons.info_outline, size: 22),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(signal.title, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 2), Text(signal.detail)])),
      ]),
    );
  }
}
