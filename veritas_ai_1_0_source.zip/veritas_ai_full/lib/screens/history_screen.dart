import 'package:flutter/material.dart';
import '../models/analysis_result.dart';
import '../services/history_service.dart';
import 'result_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _history = HistoryService();
  List<AnalysisResult> items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await _history.read();
    if (mounted) setState(() => items = data);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: CustomScrollView(
          slivers: [
            SliverPadding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 12), sliver: SliverToBoxAdapter(child: Text('History', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)))),
            if (items.isEmpty)
              const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('No analyses yet.')))
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
                sliver: SliverList.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Card(
                        child: ListTile(
                          leading: const CircleAvatar(child: Icon(Icons.insert_drive_file_outlined)),
                          title: Text(item.fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text('${item.verdict} • ${item.createdAt.toLocal()}'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ResultScreen(result: item))),
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
