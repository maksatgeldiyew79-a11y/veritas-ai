import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.onThemeChanged});
  final ValueChanged<ThemeMode> onThemeChanged;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
        children: [
          Text('Settings', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          Card(child: Column(children: [
            const ListTile(leading: Icon(Icons.lock_outline), title: Text('Privacy first'), subtitle: Text('Do not upload files except when you start an analysis.')),
            const Divider(height: 1),
            SwitchListTile(value: dark, onChanged: (v) => onThemeChanged(v ? ThemeMode.dark : ThemeMode.light), title: const Text('Dark theme')),
          ])),
          const SizedBox(height: 14),
          Card(child: Column(children: const [
            ListTile(leading: Icon(Icons.credit_card_outlined), title: Text('Premium'), subtitle: Text('Reserved for future quotas, batch analysis and enterprise features.')),
            ListTile(leading: Icon(Icons.business_outlined), title: Text('Enterprise API'), subtitle: Text('Coming in the server roadmap.')),
          ])),
          const SizedBox(height: 14),
          Card(child: const ListTile(leading: Icon(Icons.info_outline), title: Text('About VERITAS AI'), subtitle: Text('v0.1.0 MVP'))),
        ],
      ),
    );
  }
}
