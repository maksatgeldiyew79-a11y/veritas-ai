import 'package:flutter/material.dart';
import 'screens/shell.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VeritasApp());
}

class VeritasApp extends StatefulWidget {
  const VeritasApp({super.key});

  @override
  State<VeritasApp> createState() => _VeritasAppState();
}

class _VeritasAppState extends State<VeritasApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VERITAS AI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: _themeMode,
      home: Shell(
        onThemeChanged: (mode) => setState(() => _themeMode = mode),
      ),
    );
  }
}
